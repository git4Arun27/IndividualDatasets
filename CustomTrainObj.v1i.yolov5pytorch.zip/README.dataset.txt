# CustomTrainObj > 2024-12-08 8:47pm
https://universe.roboflow.com/object-detection-using-yolov5-utvob/customtrainobj

Provided by a Roboflow user
License: CC BY 4.0

