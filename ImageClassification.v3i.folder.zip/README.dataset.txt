# ImageClassification > 2024-12-16 3:00pm
https://universe.roboflow.com/object-detection-using-yolov5-utvob/imageclassification-4zpgz

Provided by a Roboflow user
License: CC BY 4.0

