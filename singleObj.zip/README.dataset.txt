# SIngleObje > 2024-12-09 10:11am
https://universe.roboflow.com/object-detection-using-yolov5-utvob/singleobje

Provided by a Roboflow user
License: CC BY 4.0

