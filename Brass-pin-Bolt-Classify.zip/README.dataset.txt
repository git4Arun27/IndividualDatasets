# ImageClassification_1 > 2024-11-26 3:56pm
https://universe.roboflow.com/object-detection-using-yolov5-utvob/imageclassification_1

Provided by a Roboflow user
License: CC BY 4.0

