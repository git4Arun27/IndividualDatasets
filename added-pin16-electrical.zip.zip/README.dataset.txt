# AutomatedAnnotation > 2024-11-05 6:36am
https://universe.roboflow.com/object-detection-using-yolov5-utvob/automatedannotation

Provided by a Roboflow user
License: CC BY 4.0

