# custom_train > 2024-12-03 4:56pm
https://universe.roboflow.com/object-detection-using-yolov5-utvob/custom_train-qbqqg

Provided by a Roboflow user
License: CC BY 4.0

