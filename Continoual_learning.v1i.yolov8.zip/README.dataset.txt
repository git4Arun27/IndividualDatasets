# Continoual_learning > 2024-11-25 12:39pm
https://universe.roboflow.com/object-detection-using-yolov5-utvob/continoual_learning

Provided by a Roboflow user
License: CC BY 4.0

