# 19ItemDetection > 2025-01-23 5:27pm
https://universe.roboflow.com/object-detection-using-yolov5-utvob/19itemdetection

Provided by a Roboflow user
License: CC BY 4.0

